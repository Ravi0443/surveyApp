import { Component, OnInit } from '@angular/core';
import { SurveyService } from '../../survey.service';

@Component({
  selector: 'app-survey-report2',
  templateUrl: './survey-report2.component.html',
  styleUrls: ['./survey-report2.component.css']
})
export class SurveyReport2Component implements OnInit {

  surveyList: any = [];

  constructor(private service: SurveyService) { }

  ngOnInit() {
      this.service.getSurvey2(this.surveyList).subscribe(result =>{
        this.surveyList = result;
      })
  }

}
