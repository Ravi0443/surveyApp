/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { SurveyReport2Component } from './survey-report2.component';

describe('SurveyReport2Component', () => {
  let component: SurveyReport2Component;
  let fixture: ComponentFixture<SurveyReport2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveyReport2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveyReport2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
