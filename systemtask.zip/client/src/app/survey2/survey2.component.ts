import { Component, OnInit } from '@angular/core';
import { Survey2 } from './survey2';
// import { NgForm } from '@angular/forms';
import { SurveyService } from '../survey.service';

@Component({
  selector: 'app-survey',
  templateUrl: './survey2.component.html',
  styleUrls: ['./survey2.component.css']
})
export class Survey2Component implements OnInit {

  data = new Survey2(false, false, false, false, false);
  successMessage = '';

  surveyData = [];
  constructor(private surveyservice: SurveyService) { }


  ngOnInit() {
  }
  onSubmit(){
    this.surveyservice.postSurvey2(this.data).subscribe(result =>{
      this.surveyData = result;
      this.successMessage = 'Thank You For Valueble Information';
     })
  }
}
