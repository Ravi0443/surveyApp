export class Survey2 {
  constructor(
    public question1: boolean,
    public question2: boolean,
    public question3: boolean,
    public question4: boolean,
    public question5: boolean
  ){

  }
}
