export class Survey {
    constructor(
      public DineIn_TakeOut: string,
      public Food_Quality: string,
      public Is_it_Worthful: boolean,
      public Overall_Service_Quality: string,
      public Cleanliness: string,
      public Order_Accuracy: string,
      public Speed_of_Service: string
    ){

    }
}
