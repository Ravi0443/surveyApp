import { Component, OnInit } from '@angular/core';
import { Survey } from './survey';
// import { NgForm } from '@angular/forms';
import { SurveyService } from '../survey.service';

@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.css']
})
export class SurveyComponent implements OnInit {

  data = new Survey('', '', false, '', '', '', '');
   surveyList: any = [];
  successMessage = '';
  constructor(private surveyservice: SurveyService) { }

  ngOnInit() {

  }
  onSubmit(){
      this.surveyservice.postSurvey(this.data).subscribe(result =>{
        this.surveyList = result;
        this.successMessage = 'Thank You For Valueble Feedback';
      });
  }
}
