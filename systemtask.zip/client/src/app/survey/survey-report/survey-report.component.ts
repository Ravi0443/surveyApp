import { Component, OnInit } from '@angular/core';
import { SurveyService } from '../../survey.service';

@Component({
  selector: 'app-servey-report',
  templateUrl: './survey-report.component.html',
  styleUrls: ['./survey-report.component.css']
})
export class SurveyReportComponent implements OnInit {

  surveyList: any = [];

  constructor(private surveyservice: SurveyService) { }

  ngOnInit() {
     this.surveyservice.getSurvey(this.surveyList).subscribe( data => {
        this.surveyList = data;
      });
  }

}
