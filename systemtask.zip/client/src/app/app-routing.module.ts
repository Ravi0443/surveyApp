import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SurveyComponent } from './survey/survey.component';
import { Survey2Component } from './survey2/survey2.component';
import { SurveyReportComponent } from './survey/survey-report/survey-report.component';
import { SurveyReport2Component } from './survey2/survey-report2/survey-report2.component';

const routes: Routes = [
  {path: '', redirectTo: '/survey', pathMatch: 'full'},
  {path: 'survey', component: SurveyComponent},
  {path: 'survey2', component: Survey2Component},
  {path: 'survey-report1', component: SurveyReportComponent},
  {path: 'survey-report2', component: SurveyReport2Component},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
