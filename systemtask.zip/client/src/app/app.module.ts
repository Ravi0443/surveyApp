import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SurveyComponent } from './survey/survey.component';
import { FormsModule } from '@angular/forms';

import { NgxPaginationModule } from 'ngx-pagination';
import { Survey2Component } from './survey2/survey2.component';
import { HttpClientModule } from '@angular/common/http';
import { SurveyReportComponent } from './survey/survey-report/survey-report.component';
import { SurveyReport2Component } from './survey2/survey-report2/survey-report2.component';


@NgModule({
   declarations: [
      AppComponent,
      SurveyComponent,
      Survey2Component,
      SurveyReportComponent,
      SurveyReport2Component
   ],
   imports: [
      BrowserModule,
      AppRoutingModule,
      FormsModule,
      NgxPaginationModule,
      HttpClientModule
   ],
   providers: [],
   bootstrap: [
      AppComponent
   ]
})
export class AppModule { }
