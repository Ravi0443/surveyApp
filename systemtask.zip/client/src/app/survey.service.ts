import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Survey } from './survey/survey';
import { Survey2 } from './survey2/survey2';

@Injectable({
  providedIn: 'root'
})
export class SurveyService {
  private url  = 'http://localhost:3000/api';

constructor(private http: HttpClient) { }

getSurvey(data) {
  return this.http.get<any>(this.url, data);
}
postSurvey(data: Survey) {
  return this.http.post<any>(this.url, data);
}
getSurvey2(data) {
    const url2 = this.url + '/survey2';
    return this.http.get<any>(url2, data);
}
postSurvey2(data: Survey2) {
  const url2 = this.url + '/survey2';
  return this.http.post<any>(url2, data);
}

}
