const mongoose = require('mongoose');

const survey2Schema = new mongoose.Schema({
    question1: Boolean,
    question2: Boolean,
    question3: Boolean,
    question4: Boolean,
    question5: Boolean
});

module.exports = mongoose.model("Survey2", survey2Schema);