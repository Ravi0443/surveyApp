const mongoose = require('mongoose');

const surveySchema = new mongoose.Schema({
    DineIn_TakeOut: String,
    Food_Quality: String,
    Is_it_Worthful: Boolean,
    Overall_Service_Quality: String,
    Cleanliness: String,
    Order_Accuracy: String,
    Speed_of_Service: String
});

module.exports = mongoose.model("Survey", surveySchema);