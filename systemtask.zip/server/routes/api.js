const express = require('express');
const router = express.Router();
const mongoose =require('mongoose');
const Survey  = require('../models/surveyModel');
const Survey2 = require('../models/survey2Model');

const db= "mongodb://localhost:27017/systemtask";

mongoose.connect(db,{ useNewUrlParser: true }, err => {
    if(err){
        console.log(err);
    }
    else{
        console.log('Connected to MongoDB')
    }
})

router.get('/',(req,res) => {
    Survey.find().exec().then(result =>{
        res.status(200).send(result);
    })
});

router.post('/', (req, res) => {
    const surveyData = req.body;
    const survey = new Survey({
        DineIn_TakeOut: surveyData.DineIn_TakeOut,
        Food_Quality: surveyData.Food_Quality,
        Is_it_Worthful: surveyData.Is_it_Worthful,
        Overall_Service_Quality: surveyData.Overall_Service_Quality,
        Cleanliness: surveyData.Cleanliness,
        Order_Accuracy: surveyData.Order_Accuracy,
        Speed_of_Service: surveyData.Speed_of_Service,
    });
    survey.save().then(result => {
        res.status(201).send(result);
    }).catch((err) => {
        res.status(500).send(err);
    });
})

router.post('/survey2', (req, res) => {
    const surveyData = req.body;
    const survey = new Survey2({
        question1: surveyData.question1,
        question2: surveyData.question2,
        question3: surveyData.question3,
        question4: surveyData.question4,
        question5: surveyData.question5
    });
    survey.save().then(result => {
        res.status(201).send(result);
    }).catch((err) => {
        res.status(500).send(err);
    });
});

router.get('/survey2',(req,res) => {
    Survey2.find().exec().then(result =>{
        res.status(200).send(result);
    })
});


module.exports = router;